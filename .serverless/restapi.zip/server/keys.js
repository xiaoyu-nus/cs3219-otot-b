module.exports = {
    mongoURI:
      "mongodb+srv://user:124578@cluster0.subt2.mongodb.net/animedb?retryWrites=true&w=majority",
  };
  