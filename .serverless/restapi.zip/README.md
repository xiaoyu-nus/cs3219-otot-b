# cs3219-otot-b

## Backend

```
cd server && nodemon dev
```

## Frontend

```
cd client && npm run serve
```

## Deploy

```
serverless deploy
```
